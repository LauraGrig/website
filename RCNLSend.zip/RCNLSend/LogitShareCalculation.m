function [sj sij]=LogitShareCalculation(theta,delta,Data)

% LogitShareCalculation
% Syntax:   [sj sij]=LogitShareCalculation(theta,delta,Data)
%
% Inputs:
%    input1 - Non linear parameters
%    input2 - Data
%
% Outputs:
%    sij    = individual market shares
%    sj     = market shares
%
% Subfunctions: none
%

% Author: Laura Grigolon and Frank Verboven
% August 2012;

%% Unpack
prods           = Data.prods;
nmkt            = Data.nmkt;
Nnodes          = Data.Nnodes;
xvu             = Data.xvu;
qweightrprods   = Data.qweightrprods;

% Market share calculation
mudel           = bsxfun(@plus,delta,xvu.*theta);
numer1          = exp(mudel);

% use multidimensional arrays
numer1          = reshape(numer1,[prods,1,nmkt,Nnodes]);
denom1          = 1 + sum(numer1);
sij             = bsxfun(@rdivide,numer1,denom1);
sj              = sum((bsxfun(@times,sij,qweightrprods)),4);
end